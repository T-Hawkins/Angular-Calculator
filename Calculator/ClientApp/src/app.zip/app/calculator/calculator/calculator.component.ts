import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators} from "@angular/forms";

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent implements OnInit {

  input:string = ""; // initialize with an empty input
  history:Map<number, string>;
  public inputForm: FormGroup<{ input: FormControl<string | null> }>;

  constructor() {
    this.history = new Map<number, string>()
    this.history.set(1, "1 + 1")
    this.history.set(2, "35 * 6")
    this.history.set(3, "65 - 23")
    this.history.set(4, "65 / 5")
    this.history.set(5, "3 * 12")
    this.inputForm = new FormGroup({
      input: new FormControl(this.input, [
        Validators.required,
        Validators.minLength(4),
      ]),
    });
  }

  ngOnInit(): void {

  }

}
